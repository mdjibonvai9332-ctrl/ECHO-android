import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

/// Set this to your deployed HTTPS API URL before release.
/// Android emulator can reach a backend running on your computer at 10.0.2.2.
/// A physical phone needs your computer's LAN IP or a deployed server URL.
class ApiService {
  static const String baseUrl = String.fromEnvironment(
    'ECHO_API_URL',
    defaultValue: 'http://10.0.2.2:4000',
  );

  static Future<Map<String, dynamic>> requestOtp(String phone) async {
    return _post('/auth/request-otp', {'phone': phone});
  }

  static Future<Map<String, dynamic>> verifyOtp(
      String phone, String code) async {
    final result = await _post('/auth/verify-otp', {
      'phone': phone,
      'code': code,
    });
    final token = result['token'];
    if (token is String && token.isNotEmpty) {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('echo_token', token);
    }
    return result;
  }

  static Future<Map<String, dynamic>> me() async {
    return _get('/me');
  }

  static Future<Map<String, dynamic>> conversations() async {
    return _get('/conversations');
  }

  static Future<Map<String, dynamic>> messages(String conversationId) async {
    return _get('/conversations/$conversationId/messages');
  }

  static Future<Map<String, dynamic>> sendMessage(
      String conversationId, String body) async {
    return _post('/conversations/$conversationId/messages', {'body': body},
        authenticated: true);
  }

  static Future<Map<String, dynamic>> _post(
    String path,
    Map<String, dynamic> body, {
    bool authenticated = false,
  }) async {
    final headers = await _headers(authenticated);
    final response = await http.post(
      Uri.parse('$baseUrl$path'),
      headers: headers,
      body: jsonEncode(body),
    ).timeout(const Duration(seconds: 20));
    return _decode(response);
  }

  static Future<Map<String, dynamic>> _get(String path) async {
    final response = await http.get(
      Uri.parse('$baseUrl$path'),
      headers: await _headers(true),
    ).timeout(const Duration(seconds: 20));
    return _decode(response);
  }

  static Future<Map<String, String>> _headers(bool authenticated) async {
    final headers = <String, String>{
      'Content-Type': 'application/json',
      'Accept': 'application/json',
    };
    if (authenticated) {
      final prefs = await SharedPreferences.getInstance();
      final token = prefs.getString('echo_token');
      if (token != null) headers['Authorization'] = 'Bearer $token';
    }
    return headers;
  }

  static Map<String, dynamic> _decode(http.Response response) {
    final dynamic decoded =
        response.body.isEmpty ? <String, dynamic>{} : jsonDecode(response.body);
    final data = decoded is Map<String, dynamic>
        ? decoded
        : <String, dynamic>{'data': decoded};
    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw Exception(data['error'] ?? 'Server error ${response.statusCode}');
    }
    return data;
  }
}
