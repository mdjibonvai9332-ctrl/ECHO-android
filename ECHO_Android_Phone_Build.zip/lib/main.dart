import 'package:flutter/material.dart';
import 'screens/echo_app.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const EchoApp());
}
