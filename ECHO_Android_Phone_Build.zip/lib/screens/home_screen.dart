import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../services/api_service.dart';
import 'echo_app.dart';
import 'login_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int tab = 0;
  String displayName = 'ECHO User';
  String phone = '';
  bool loading = true;
  List<dynamic> conversations = [];

  @override
  void initState() { super.initState(); load(); }

  Future<void> load() async {
    try {
      final me = await ApiService.me();
      final user = me['user'] as Map<String, dynamic>? ?? {};
      final chats = await ApiService.conversations();
      if (!mounted) return;
      setState(() {
        displayName = user['displayName'] ?? 'ECHO User';
        phone = user['phone'] ?? '';
        conversations = chats['conversations'] as List<dynamic>? ?? [];
        loading = false;
      });
    } catch (_) {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> logout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('echo_token');
    if (!mounted) return;
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => const LoginScreen()), (_) => false);
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      _chats(),
      _simple('Calls', Icons.call_outlined, 'Your recent voice and video calls will appear here.'),
      _simple('Contacts', Icons.contacts_outlined, 'Find and invite people to ECHO.'),
      _simple('Groups', Icons.groups_outlined, 'Your ECHO groups will appear here.'),
      _profile(),
    ];
    return Scaffold(
      appBar: AppBar(
        title: Row(children: [
          Container(width: 34, height: 34, decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [echoBlue, echoCyan]),
            borderRadius: BorderRadius.circular(11)),
            child: const Icon(Icons.forum_rounded, color: Colors.white, size: 21)),
          const SizedBox(width: 10),
          const Text('ECHO', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.3)),
        ]),
        actions: [
          IconButton(onPressed: load, icon: const Icon(Icons.refresh)),
          IconButton(onPressed: () {}, icon: const Icon(Icons.search)),
        ],
      ),
      body: pages[tab],
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (v) => setState(() => tab = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.chat_bubble_outline), selectedIcon: Icon(Icons.chat_bubble), label: 'Chats'),
          NavigationDestination(icon: Icon(Icons.call_outlined), label: 'Calls'),
          NavigationDestination(icon: Icon(Icons.contacts_outlined), label: 'Contacts'),
          NavigationDestination(icon: Icon(Icons.groups_outlined), label: 'Groups'),
          NavigationDestination(icon: Icon(Icons.person_outline), label: 'Profile'),
        ],
      ),
    );
  }

  Widget _chats() {
    if (loading) return const Center(child: CircularProgressIndicator());
    return RefreshIndicator(
      onRefresh: load,
      child: ListView(padding: const EdgeInsets.fromLTRB(16, 12, 16, 20), children: [
        const Text('Messages', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w800)),
        const SizedBox(height: 15),
        TextField(
          decoration: InputDecoration(
            hintText: 'Search messages or people',
            prefixIcon: const Icon(Icons.search),
            filled: true, fillColor: const Color(0xFFF3F6FB),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: BorderSide.none),
          ),
        ),
        const SizedBox(height: 14),
        if (conversations.isEmpty)
          const Padding(
            padding: EdgeInsets.only(top: 65),
            child: Column(children: [
              Icon(Icons.forum_outlined, size: 62, color: echoCyan),
              SizedBox(height: 12),
              Text('No conversations yet', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              SizedBox(height: 5),
              Text('Start a conversation with an ECHO user.', style: TextStyle(color: Colors.blueGrey)),
            ]),
          )
        else
          ...conversations.map((c) => ListTile(
            contentPadding: const EdgeInsets.symmetric(vertical: 5),
            leading: const CircleAvatar(backgroundColor: Color(0xFFE4F2FF), child: Icon(Icons.person, color: echoBlue)),
            title: Text('Conversation', style: const TextStyle(fontWeight: FontWeight.w700)),
            subtitle: Text('ID: ${c['conversationId']}', maxLines: 1, overflow: TextOverflow.ellipsis),
            onTap: () => Navigator.push(context, MaterialPageRoute(
              builder: (_) => ConversationScreen(conversationId: c['conversationId'].toString()))),
          )),
      ]),
    );
  }

  Widget _simple(String title, IconData icon, String subtitle) => Center(
    child: Padding(padding: const EdgeInsets.all(28), child: Column(
      mainAxisSize: MainAxisSize.min, children: [
        Icon(icon, size: 65, color: echoBlue),
        const SizedBox(height: 14),
        Text(title, style: const TextStyle(fontSize: 23, fontWeight: FontWeight.bold)),
        const SizedBox(height: 7),
        Text(subtitle, textAlign: TextAlign.center, style: const TextStyle(color: Colors.blueGrey)),
      ],
    )),
  );

  Widget _profile() => ListView(padding: const EdgeInsets.all(22), children: [
    const SizedBox(height: 25),
    const CircleAvatar(radius: 43, backgroundColor: Color(0xFFE4F2FF),
      child: Icon(Icons.person, size: 48, color: echoBlue)),
    const SizedBox(height: 14),
    Center(child: Text(displayName, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold))),
    Center(child: Text(phone, style: const TextStyle(color: Colors.blueGrey))),
    const SizedBox(height: 28),
    ListTile(leading: const Icon(Icons.settings_outlined), title: const Text('Settings'), onTap: () {}),
    ListTile(leading: const Icon(Icons.privacy_tip_outlined), title: const Text('Privacy'), onTap: () {}),
    ListTile(leading: const Icon(Icons.logout, color: Colors.red), title: const Text('Log out', style: TextStyle(color: Colors.red)), onTap: logout),
  ]);

}

class ConversationScreen extends StatefulWidget {
  final String conversationId;
  const ConversationScreen({super.key, required this.conversationId});
  @override
  State<ConversationScreen> createState() => _ConversationScreenState();
}

class _ConversationScreenState extends State<ConversationScreen> {
  final input = TextEditingController();
  List<dynamic> messages = [];
  bool loading = true;

  @override
  void initState() { super.initState(); load(); }
  Future<void> load() async {
    try {
      final result = await ApiService.messages(widget.conversationId);
      if (mounted) setState(() {
        messages = result['messages'] as List<dynamic>? ?? [];
        loading = false;
      });
    } catch (_) { if (mounted) setState(() => loading = false); }
  }
  Future<void> send() async {
    final body = input.text.trim();
    if (body.isEmpty) return;
    input.clear();
    try {
      await ApiService.sendMessage(widget.conversationId, body);
      await load();
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
    }
  }
  @override
  void dispose() { input.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('ECHO Chat'), actions: [
      IconButton(onPressed: () {}, icon: const Icon(Icons.call_outlined)),
      IconButton(onPressed: () {}, icon: const Icon(Icons.videocam_outlined)),
    ]),
    body: Column(children: [
      Expanded(child: loading ? const Center(child: CircularProgressIndicator()) :
        ListView(padding: const EdgeInsets.all(16), children: messages.map((m) =>
          Align(alignment: Alignment.centerLeft, child: Container(
            margin: const EdgeInsets.only(bottom: 9),
            padding: const EdgeInsets.all(12),
            constraints: const BoxConstraints(maxWidth: 290),
            decoration: BoxDecoration(color: const Color(0xFFEAF3FF), borderRadius: BorderRadius.circular(15)),
            child: Text(m['body']?.toString() ?? ''),
          ))).toList())),
      SafeArea(top: false, child: Padding(
        padding: const EdgeInsets.fromLTRB(12, 8, 12, 10),
        child: Row(children: [
          Expanded(child: TextField(controller: input, textInputAction: TextInputAction.send,
            onSubmitted: (_) => send(), decoration: const InputDecoration(hintText: 'Write a message...'))),
          const SizedBox(width: 8),
          IconButton.filled(onPressed: send, icon: const Icon(Icons.send)),
        ]),
      )),
    ]),
  );
}
