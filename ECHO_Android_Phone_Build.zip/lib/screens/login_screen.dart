import 'package:flutter/material.dart';
import '../services/api_service.dart';
import 'echo_app.dart';
import 'otp_screen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final phone = TextEditingController(text: '+880');
  bool loading = false;

  Future<void> submit() async {
    final value = phone.text.trim();
    if (!RegExp(r'^\+[1-9]\d{7,14}$').hasMatch(value)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Enter phone in international format, e.g. +8801XXXXXXXXX')),
      );
      return;
    }
    setState(() => loading = true);
    try {
      await ApiService.requestOtp(value);
      if (!mounted) return;
      Navigator.push(context, MaterialPageRoute(
        builder: (_) => OtpScreen(phone: value),
      ));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(e.toString().replaceFirst('Exception: ', ''))),
      );
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  void dispose() { phone.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(26),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Container(
                  height: 150,
                  alignment: Alignment.center,
                  child: Image.asset('assets/echo-logo.png', fit: BoxFit.contain,
                    errorBuilder: (_, __, ___) => const Icon(Icons.forum_rounded, size: 90, color: echoBlue)),
                ),
                const SizedBox(height: 12),
                const Text('Welcome to ECHO',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 27, fontWeight: FontWeight.w800, color: echoInk)),
                const SizedBox(height: 8),
                const Text('Connect Beyond Distance.',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.blueGrey)),
                const SizedBox(height: 38),
                const Text('Your phone number', style: TextStyle(fontWeight: FontWeight.w700)),
                const SizedBox(height: 10),
                TextField(
                  controller: phone,
                  keyboardType: TextInputType.phone,
                  decoration: const InputDecoration(
                    prefixIcon: Icon(Icons.phone_android),
                    hintText: '+8801XXXXXXXXX',
                  ),
                ),
                const SizedBox(height: 18),
                SizedBox(height: 52, child: FilledButton(
                  onPressed: loading ? null : submit,
                  child: loading
                    ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                    : const Text('Continue', style: TextStyle(fontWeight: FontWeight.bold)),
                )),
                const SizedBox(height: 16),
                const Text('By continuing, you agree to ECHO’s Terms and Privacy Policy.',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 11, color: Colors.blueGrey)),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
