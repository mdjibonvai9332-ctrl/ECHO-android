import 'package:flutter/material.dart';
import '../services/api_service.dart';
import 'home_screen.dart';
import 'echo_app.dart';

class OtpScreen extends StatefulWidget {
  final String phone;
  const OtpScreen({super.key, required this.phone});
  @override
  State<OtpScreen> createState() => _OtpScreenState();
}

class _OtpScreenState extends State<OtpScreen> {
  final code = TextEditingController();
  bool loading = false;

  Future<void> verify() async {
    if (!RegExp(r'^\d{6}$').hasMatch(code.text.trim())) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Enter the 6-digit OTP')),
      );
      return;
    }
    setState(() => loading = true);
    try {
      await ApiService.verifyOtp(widget.phone, code.text.trim());
      if (!mounted) return;
      Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(builder: (_) => const HomeScreen()),
        (_) => false,
      );
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(e.toString().replaceFirst('Exception: ', ''))),
      );
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  void dispose() { code.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Verify number')),
    body: Padding(
      padding: const EdgeInsets.all(24),
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        const SizedBox(height: 30),
        const Icon(Icons.mark_email_read_outlined, size: 64, color: echoBlue),
        const SizedBox(height: 20),
        const Text('Enter verification code',
          textAlign: TextAlign.center,
          style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        Text('We sent a code to ${widget.phone}',
          textAlign: TextAlign.center, style: const TextStyle(color: Colors.blueGrey)),
        const SizedBox(height: 28),
        TextField(
          controller: code,
          keyboardType: TextInputType.number,
          maxLength: 6,
          textAlign: TextAlign.center,
          style: const TextStyle(fontSize: 26, letterSpacing: 12, fontWeight: FontWeight.bold),
          decoration: const InputDecoration(hintText: '••••••', counterText: ''),
        ),
        const SizedBox(height: 20),
        SizedBox(height: 52, child: FilledButton(
          onPressed: loading ? null : verify,
          child: loading ? const CircularProgressIndicator(color: Colors.white)
            : const Text('Verify & Continue'),
        )),
      ]),
    ),
  );
}
